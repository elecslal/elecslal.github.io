<!DOCTYPE html>
<html  dir="ltr" lang="en" xml:lang="en">
<head>
    <title>elecslal: Course categories</title>
    <link rel="shortcut icon" href="http://elecslal.net/theme/image.php/standard/theme/1393363531/favicon" />
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="moodle, elecslal: Course categories" />
<script type="text/javascript">
//<![CDATA[
var M = {}; M.yui = {};
M.pageloadstarttime = new Date();
M.cfg = {"wwwroot":"http:\/\/elecslal.net","sesskey":"iJhtJyp6Mi","loadingicon":"http:\/\/elecslal.net\/theme\/image.php\/standard\/core\/1393363531\/i\/loading_small","themerev":"1393363531","slasharguments":1,"theme":"standard","jsrev":"1393363531","svgicons":true};var yui1ConfigFn = function(me) {if(/-skin|reset|fonts|grids|base/.test(me.name)){me.type='css';me.path=me.path.replace(/\.js/,'.css');me.path=me.path.replace(/\/yui2-skin/,'/assets/skins/sam/yui2-skin')}};
var yui2ConfigFn = function(me) {var parts=me.name.replace(/^moodle-/,'').split('-'),component=parts.shift(),module=parts[0],min='-min';if(/-(skin|core)$/.test(me.name)){parts.pop();me.type='css';min=''};if(module){var filename=parts.join('-');me.path=component+'/'+module+'/'+filename+min+'.'+me.type}else me.path=component+'/'+component+'.'+me.type};
YUI_config = {"debug":false,"base":"http:\/\/elecslal.net\/lib\/yuilib\/3.13.0\/","comboBase":"http:\/\/elecslal.net\/theme\/yui_combo.php?","combine":true,"filter":null,"insertBefore":"firstthemesheet","groups":{"yui2":{"base":"http:\/\/elecslal.net\/lib\/yuilib\/2in3\/2.9.0\/build\/","comboBase":"http:\/\/elecslal.net\/theme\/yui_combo.php?","combine":true,"ext":false,"root":"2in3\/2.9.0\/build\/","patterns":{"yui2-":{"group":"yui2","configFn":yui1ConfigFn}}},"moodle":{"name":"moodle","base":"http:\/\/elecslal.net\/theme\/yui_combo.php?m\/1393363531\/","combine":true,"comboBase":"http:\/\/elecslal.net\/theme\/yui_combo.php?","ext":false,"root":"m\/1393363531\/","patterns":{"moodle-":{"group":"moodle","configFn":yui2ConfigFn}},"filter":null,"modules":{"moodle-core-chooserdialogue":{"requires":["base","panel","moodle-core-notification"]},"moodle-core-notification":{"requires":["moodle-core-notification-dialogue","moodle-core-notification-alert","moodle-core-notification-confirm","moodle-core-notification-exception","moodle-core-notification-ajaxexception"]},"moodle-core-notification-dialogue":{"requires":["base","node","panel","event-key","dd-plugin","moodle-core-lockscroll"]},"moodle-core-notification-alert":{"requires":["moodle-core-notification-dialogue"]},"moodle-core-notification-confirm":{"requires":["moodle-core-notification-dialogue"]},"moodle-core-notification-exception":{"requires":["moodle-core-notification-dialogue"]},"moodle-core-notification-ajaxexception":{"requires":["moodle-core-notification-dialogue"]},"moodle-core-actionmenu":{"requires":["base","event","node-event-simulate"]},"moodle-core-formautosubmit":{"requires":["base","event-key"]},"moodle-core-dock":{"requires":["base","node","event-custom","event-mouseenter","event-resize","escape","moodle-core-dock-loader"]},"moodle-core-dock-loader":{"requires":["escape"]},"moodle-core-tooltip":{"requires":["base","node","io-base","moodle-core-notification","json-parse","widget-position","widget-position-align","event-outside","cache-base"]},"moodle-core-lockscroll":{"requires":["plugin","base-build"]},"moodle-core-formchangechecker":{"requires":["base","event-focus"]},"moodle-core-popuphelp":{"requires":["moodle-core-tooltip"]},"moodle-core-blocks":{"requires":["base","node","io","dom","dd","dd-scroll","moodle-core-dragdrop","moodle-core-notification"]},"moodle-calendar-eventmanager":{"requires":["base","node","event-mouseenter","overlay","moodle-calendar-eventmanager-skin"]},"moodle-course-categoryexpander":{"requires":["node","event-key"]},"moodle-course-util":{"requires":["node"],"use":["moodle-course-util-base"],"submodules":{"moodle-course-util-base":{},"moodle-course-util-section":{"requires":["node","moodle-course-util-base"]},"moodle-course-util-cm":{"requires":["node","moodle-course-util-base"]}}},"moodle-course-management":{"requires":["base","node","io-base","moodle-core-notification-exception","json-parse","dd-constrain","dd-proxy","dd-drop","dd-delegate","node-event-delegate"]},"moodle-mod_quiz-autosave":{"requires":["base","node","event","event-valuechange","node-event-delegate","io-form"]},"moodle-block_navigation-navigation":{"requires":["base","io-base","node","event-synthetic","event-delegate","json-parse"]},"moodle-filter_glossary-autolinker":{"requires":["base","node","io-base","json-parse","event-delegate","overlay","moodle-core-notification-alert"]},"moodle-tool_capability-search":{"requires":["base","node"]},"moodle-theme_bootstrapbase-bootstrap":{"requires":["node","selector-css3"]},"moodle-assignfeedback_editpdf-editor":{"requires":["base","event","node","io","graphics","json","event-move","querystring-stringify-simple","moodle-core-notification-dialog","moodle-core-notification-exception","moodle-core-notification-ajaxexception"]}}}},"modules":{"core_filepicker":{"name":"core_filepicker","fullpath":"http:\/\/elecslal.net\/lib\/javascript.php\/1393363531\/repository\/filepicker.js","requires":["base","node","node-event-simulate","json","async-queue","io-base","io-upload-iframe","io-form","yui2-treeview","panel","cookie","datatable","datatable-sort","resize-plugin","dd-plugin","escape","moodle-core_filepicker"]}}};
M.yui.loader = {modules: {}};

//]]>
</script>
<link rel="stylesheet" type="text/css" href="http://elecslal.net/theme/yui_combo.php?3.13.0/cssreset/cssreset-min.css&amp;3.13.0/cssfonts/cssfonts-min.css&amp;3.13.0/cssgrids/cssgrids-min.css&amp;3.13.0/cssbase/cssbase-min.css" /><link rel="stylesheet" type="text/css" href="http://elecslal.net/theme/yui_combo.php?rollup/3.13.0/yui-moodlesimple-min.css" /><script type="text/javascript" src="http://elecslal.net/theme/yui_combo.php?rollup/3.13.0/yui-moodlesimple-min.js"></script><script type="text/javascript" src="http://elecslal.net/theme/yui_combo.php?rollup/1393363531/mcore-min.js"></script><script id="firstthemesheet" type="text/css">/** Required in order to fix style inclusion problems in IE with YUI **/</script><link rel="stylesheet" type="text/css" href="http://elecslal.net/theme/styles.php/standard/1393363531/all" />
<script type="text/javascript" src="http://elecslal.net/lib/javascript.php/1393363531/lib/javascript-static.js"></script>
</head>
<body id="page-course-index" class="format-site  path-course dir-ltr lang-en yui-skin-sam yui3-skin-sam elecslal-net pagelayout-coursecategory course-1 context-1 notloggedin side-pre-only">
<div class="skiplinks"><a class="skip" href="#maincontent">Skip to main content</a></div>
<script type="text/javascript">
//<![CDATA[
document.body.className += ' jsenabled';
//]]>
</script>

<div id="page">
    <div id="page-header">
                <h1 class="headermain">Electronics Course for G.C.E Advanced Level</h1>
        <div class="headermenu"><div class="logininfo">You are not logged in. (<a href="http://elecslal.net/login/index.php">Log in</a>)</div></div>                                    <div class="navbar clearfix">
                <div class="breadcrumb"><span class="accesshide">Page path</span><ul role="navigation"><li><a href="http://elecslal.net/">Home</a></li><li> <span class="accesshide " ><span class="arrow_text">/</span>&nbsp;</span><span class="arrow sep">&#x25BA;</span> <a href="http://elecslal.net/course/index.php">Courses</a></li></ul></div>
                <div class="navbutton"> <form id="coursesearchnavbar" action="http://elecslal.net/course/search.php" method="get"><fieldset class="coursesearchbox invisiblefieldset"><label for="navsearchbox">Search courses: </label><input type="text" id="navsearchbox" size="20" name="search" value="" /><input type="submit" value="Go" /></fieldset></form></div>
            </div>
            </div>
<!-- END OF HEADER -->

    <div id="page-content">
        <div id="region-main-box">
            <div id="region-post-box">

                <div id="region-main-wrap">
                    <div id="region-main">
                        <div class="region-content">
                                                        <div role="main"><span id="maincontent"></span><span></span><div class="course_category_tree clearfix category-browse category-browse-0"><div class="collapsible-actions"><a class="collapseexpand collapse-all disabled" href="#">Collapse all</a></div><div class="content"><div class="subcategories"><div class="category notloaded with_children collapsed" data-categoryid="1" data-depth="1" data-showcourses="15" data-type="0"><div class="info"><h3 class="categoryname"><a href="http://elecslal.net/course/index.php?categoryid=1">Miscellaneous</a></h3></div><div class="content"></div></div><div class="category notloaded with_children collapsed" data-categoryid="3" data-depth="1" data-showcourses="15" data-type="0"><div class="info"><h3 class="categoryname"><a href="http://elecslal.net/course/index.php?categoryid=3">Junction Diodes</a></h3></div><div class="content"></div></div><div class="category notloaded with_children collapsed" data-categoryid="4" data-depth="1" data-showcourses="15" data-type="0"><div class="info"><h3 class="categoryname"><a href="http://elecslal.net/course/index.php?categoryid=4">Transistor</a></h3></div><div class="content"></div></div><div class="category notloaded with_children collapsed" data-categoryid="5" data-depth="1" data-showcourses="15" data-type="0"><div class="info"><h3 class="categoryname"><a href="http://elecslal.net/course/index.php?categoryid=5">Operational Amplifiers </a></h3></div><div class="content"></div></div><div class="category notloaded with_children collapsed" data-categoryid="6" data-depth="1" data-showcourses="15" data-type="0"><div class="info"><h3 class="categoryname"><a href="http://elecslal.net/course/index.php?categoryid=6">Digital Electronics</a></h3></div><div class="content"></div></div></div></div></div><form id="coursesearch2" action="http://elecslal.net/course/search.php" method="get"><fieldset class="coursesearchbox invisiblefieldset"><label for="coursesearchbox">Search courses: </label><input type="text" id="coursesearchbox" size="30" name="search" value="" /><input type="submit" value="Go" /></fieldset></form><div class="buttons"></div></div>                                                    </div>
                    </div>
                </div>

                                <div id="region-pre" class="block-region">
                    <div class="region-content">
                            <a href="#sb-1" class="skip-block">Skip Navigation</a><div id="inst4" class="block_navigation  block" role="navigation" data-block="navigation" data-instanceid="4" aria-labelledby="instance-4-header" data-dockable="1"><div class="header"><div class="title"><div class="block_action"></div><h2 id="instance-4-header">Navigation</h2></div></div><div class="content"><ul class="block_tree list"><li class="type_unknown depth_1 contains_branch" aria-expanded="true"><p class="tree_item branch canexpand navigation_node"><a href="http://elecslal.net/">Home</a></p><ul><li class="type_activity depth_2 item_with_icon"><p class="tree_item leaf hasicon"><a title="Forum" href="http://elecslal.net/mod/forum/view.php?id=11"><img alt="Forum" class="smallicon navicon" title="Forum" src="http://elecslal.net/theme/image.php/standard/forum/1393363531/icon" />Site news</a></p></li>
<li class="type_activity depth_2 collapsed item_with_icon"><p class="tree_item leaf hasicon" id="expandable_branch_40_8"><a title="Chat" href="http://elecslal.net/mod/chat/view.php?id=8"><img alt="Chat" class="smallicon navicon" title="Chat" src="http://elecslal.net/theme/image.php/standard/chat/1393363531/icon" />Educational Chat</a></p></li>
<li class="type_system depth_2 contains_branch current_branch" aria-expanded="true"><p class="tree_item branch active_tree_node" id="expandable_branch_0_courses"><a href="http://elecslal.net/course/index.php">Courses</a></p></li></ul></li></ul></div></div><span id="sb-1" class="skip-block-to"></span>
                    </div>
                </div>
                
                
            </div>
        </div>
    </div>

<!-- START OF FOOTER -->
            <div id="page-footer" class="clearfix">
        <p class="helplink"></p>
        <div class="logininfo">You are not logged in. (<a href="http://elecslal.net/login/index.php">Log in</a>)</div><div class="homelink"><a href="http://elecslal.net/">Home</a></div>    </div>
        <div class="clearfix"></div>
</div>
<script type="text/javascript">
//<![CDATA[
M.str = {"moodle":{"lastmodified":"Last modified","name":"Name","error":"Error","info":"Information","collapseall":"Collapse all","expandall":"Expand all","viewallcourses":"View all courses","morehelp":"More help","loadinghelp":"Loading...","cancel":"Cancel","yes":"Yes"},"repository":{"type":"Type","size":"Size","invalidjson":"Invalid JSON string","nofilesattached":"No files attached","filepicker":"File picker","logout":"Logout","nofilesavailable":"No files available","norepositoriesavailable":"Sorry, none of your current repositories can return files in the required format.","fileexistsdialogheader":"File exists","fileexistsdialog_editor":"A file with that name has already been attached to the text you are editing.","fileexistsdialog_filemanager":"A file with that name has already been attached","renameto":"Rename to \"{$a}\"","referencesexist":"There are {$a} alias\/shortcut files that use this file as their source","select":"Select"},"block":{"addtodock":"Move this to the dock","undockitem":"Undock this item","dockblock":"Dock {$a} block","undockblock":"Undock {$a} block","undockall":"Undock all","hidedockpanel":"Hide the dock panel","hidepanel":"Hide panel"},"langconfig":{"thisdirectionvertical":"btt"},"admin":{"confirmation":"Confirmation"}};
//]]>
</script>
<script type="text/javascript">
//<![CDATA[
var navtreeexpansions4 = [{"id":"expandable_branch_40_8","key":"8","type":40},{"id":"expandable_branch_0_courses","key":"courses","type":0}];
//]]>
</script>
<script type="text/javascript">
//<![CDATA[
YUI().use('node', function(Y) {
M.util.load_flowplayer();
setTimeout("fix_column_widths()", 20);
M.yui.galleryversion="2010.04.08-12-35";Y.use("moodle-core-dock-loader",function() {M.core.dock.loader.initLoader();
});
M.yui.galleryversion="2010.04.08-12-35";Y.use("moodle-course-categoryexpander",function() {Y.Moodle.course.categoryexpander.init();
});
M.yui.galleryversion="2010.04.08-12-35";Y.use("moodle-block_navigation-navigation",function() {M.block_navigation.init_add_tree({"id":"4","instance":"4","candock":true,"courselimit":"20","expansionlimit":0});
});
M.yui.galleryversion="2010.04.08-12-35";Y.use("moodle-block_navigation-navigation",function() {M.block_navigation.init_add_tree({"id":"5","instance":"5","candock":true});
});
M.util.help_popups.setup(Y);
M.yui.galleryversion="2010.04.08-12-35";Y.use("moodle-core-popuphelp",function() {M.core.init_popuphelp();
});
M.util.init_block_hider(Y, {"id":"inst4","title":"Navigation","preference":"block4hidden","tooltipVisible":"Hide Navigation block","tooltipHidden":"Show Navigation block"});
 M.util.js_pending('random5d923fd4811d03'); Y.on('domready', function() { M.util.js_complete("init");  M.util.js_complete('random5d923fd4811d03'); });

});
//]]>
</script>
</body>
</html>