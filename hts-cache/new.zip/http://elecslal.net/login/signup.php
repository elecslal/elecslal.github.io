<!DOCTYPE html>
<html  dir="ltr" lang="en" xml:lang="en">
<head>
    <title>New account</title>
    <link rel="shortcut icon" href="http://elecslal.net/theme/image.php/standard/theme/1393363531/favicon" />
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="moodle, New account" />
<script type="text/javascript">
//<![CDATA[
var M = {}; M.yui = {};
M.pageloadstarttime = new Date();
M.cfg = {"wwwroot":"http:\/\/elecslal.net","sesskey":"iJhtJyp6Mi","loadingicon":"http:\/\/elecslal.net\/theme\/image.php\/standard\/core\/1393363531\/i\/loading_small","themerev":"1393363531","slasharguments":1,"theme":"standard","jsrev":"1393363531","svgicons":true};var yui1ConfigFn = function(me) {if(/-skin|reset|fonts|grids|base/.test(me.name)){me.type='css';me.path=me.path.replace(/\.js/,'.css');me.path=me.path.replace(/\/yui2-skin/,'/assets/skins/sam/yui2-skin')}};
var yui2ConfigFn = function(me) {var parts=me.name.replace(/^moodle-/,'').split('-'),component=parts.shift(),module=parts[0],min='-min';if(/-(skin|core)$/.test(me.name)){parts.pop();me.type='css';min=''};if(module){var filename=parts.join('-');me.path=component+'/'+module+'/'+filename+min+'.'+me.type}else me.path=component+'/'+component+'.'+me.type};
YUI_config = {"debug":false,"base":"http:\/\/elecslal.net\/lib\/yuilib\/3.13.0\/","comboBase":"http:\/\/elecslal.net\/theme\/yui_combo.php?","combine":true,"filter":null,"insertBefore":"firstthemesheet","groups":{"yui2":{"base":"http:\/\/elecslal.net\/lib\/yuilib\/2in3\/2.9.0\/build\/","comboBase":"http:\/\/elecslal.net\/theme\/yui_combo.php?","combine":true,"ext":false,"root":"2in3\/2.9.0\/build\/","patterns":{"yui2-":{"group":"yui2","configFn":yui1ConfigFn}}},"moodle":{"name":"moodle","base":"http:\/\/elecslal.net\/theme\/yui_combo.php?m\/1393363531\/","combine":true,"comboBase":"http:\/\/elecslal.net\/theme\/yui_combo.php?","ext":false,"root":"m\/1393363531\/","patterns":{"moodle-":{"group":"moodle","configFn":yui2ConfigFn}},"filter":null,"modules":{"moodle-core-chooserdialogue":{"requires":["base","panel","moodle-core-notification"]},"moodle-core-notification":{"requires":["moodle-core-notification-dialogue","moodle-core-notification-alert","moodle-core-notification-confirm","moodle-core-notification-exception","moodle-core-notification-ajaxexception"]},"moodle-core-notification-dialogue":{"requires":["base","node","panel","event-key","dd-plugin","moodle-core-lockscroll"]},"moodle-core-notification-alert":{"requires":["moodle-core-notification-dialogue"]},"moodle-core-notification-confirm":{"requires":["moodle-core-notification-dialogue"]},"moodle-core-notification-exception":{"requires":["moodle-core-notification-dialogue"]},"moodle-core-notification-ajaxexception":{"requires":["moodle-core-notification-dialogue"]},"moodle-core-actionmenu":{"requires":["base","event","node-event-simulate"]},"moodle-core-formautosubmit":{"requires":["base","event-key"]},"moodle-core-dock":{"requires":["base","node","event-custom","event-mouseenter","event-resize","escape","moodle-core-dock-loader"]},"moodle-core-dock-loader":{"requires":["escape"]},"moodle-core-tooltip":{"requires":["base","node","io-base","moodle-core-notification","json-parse","widget-position","widget-position-align","event-outside","cache-base"]},"moodle-core-lockscroll":{"requires":["plugin","base-build"]},"moodle-core-formchangechecker":{"requires":["base","event-focus"]},"moodle-core-popuphelp":{"requires":["moodle-core-tooltip"]},"moodle-core-blocks":{"requires":["base","node","io","dom","dd","dd-scroll","moodle-core-dragdrop","moodle-core-notification"]},"moodle-calendar-eventmanager":{"requires":["base","node","event-mouseenter","overlay","moodle-calendar-eventmanager-skin"]},"moodle-course-categoryexpander":{"requires":["node","event-key"]},"moodle-course-util":{"requires":["node"],"use":["moodle-course-util-base"],"submodules":{"moodle-course-util-base":{},"moodle-course-util-section":{"requires":["node","moodle-course-util-base"]},"moodle-course-util-cm":{"requires":["node","moodle-course-util-base"]}}},"moodle-course-management":{"requires":["base","node","io-base","moodle-core-notification-exception","json-parse","dd-constrain","dd-proxy","dd-drop","dd-delegate","node-event-delegate"]},"moodle-mod_quiz-autosave":{"requires":["base","node","event","event-valuechange","node-event-delegate","io-form"]},"moodle-block_navigation-navigation":{"requires":["base","io-base","node","event-synthetic","event-delegate","json-parse"]},"moodle-filter_glossary-autolinker":{"requires":["base","node","io-base","json-parse","event-delegate","overlay","moodle-core-notification-alert"]},"moodle-tool_capability-search":{"requires":["base","node"]},"moodle-theme_bootstrapbase-bootstrap":{"requires":["node","selector-css3"]},"moodle-assignfeedback_editpdf-editor":{"requires":["base","event","node","io","graphics","json","event-move","querystring-stringify-simple","moodle-core-notification-dialog","moodle-core-notification-exception","moodle-core-notification-ajaxexception"]}}}},"modules":{"core_filepicker":{"name":"core_filepicker","fullpath":"http:\/\/elecslal.net\/lib\/javascript.php\/1393363531\/repository\/filepicker.js","requires":["base","node","node-event-simulate","json","async-queue","io-base","io-upload-iframe","io-form","yui2-treeview","panel","cookie","datatable","datatable-sort","resize-plugin","dd-plugin","escape","moodle-core_filepicker"]}}};
M.yui.loader = {modules: {}};

//]]>
</script>
<link rel="stylesheet" type="text/css" href="http://elecslal.net/theme/yui_combo.php?3.13.0/cssreset/cssreset-min.css&amp;3.13.0/cssfonts/cssfonts-min.css&amp;3.13.0/cssgrids/cssgrids-min.css&amp;3.13.0/cssbase/cssbase-min.css" /><link rel="stylesheet" type="text/css" href="http://elecslal.net/theme/yui_combo.php?rollup/3.13.0/yui-moodlesimple-min.css" /><script type="text/javascript" src="http://elecslal.net/theme/yui_combo.php?rollup/3.13.0/yui-moodlesimple-min.js"></script><script type="text/javascript" src="http://elecslal.net/theme/yui_combo.php?rollup/1393363531/mcore-min.js"></script><script id="firstthemesheet" type="text/css">/** Required in order to fix style inclusion problems in IE with YUI **/</script><link rel="stylesheet" type="text/css" href="http://elecslal.net/theme/styles.php/standard/1393363531/all" />
<script type="text/javascript" src="http://elecslal.net/lib/javascript.php/1393363531/lib/javascript-static.js"></script>

<meta name="robots" content="noindex" /></head>
<body id="page-login-signup" class="format-site  path-login dir-ltr lang-en yui-skin-sam yui3-skin-sam elecslal-net pagelayout-base course-1 context-1 notloggedin content-only">
<div class="skiplinks"><a class="skip" href="#maincontent">Skip to main content</a></div>
<script type="text/javascript">
//<![CDATA[
document.body.className += ' jsenabled';
//]]>
</script>

<div id="page">
    <div id="page-header">
                <h1 class="headermain">Electronics Course for G.C.E Advanced Level</h1>
        <div class="headermenu"><div class="logininfo">You are not logged in. (<a href="http://elecslal.net/login/index.php">Log in</a>)</div></div>                                    <div class="navbar clearfix">
                <div class="breadcrumb"><span class="accesshide">Page path</span><ul role="navigation"><li><a href="http://elecslal.net/">Home</a></li><li> <span class="accesshide " ><span class="arrow_text">/</span>&nbsp;</span><span class="arrow sep">&#x25BA;</span> <span tabindex="0">Log in</span></li><li> <span class="accesshide " ><span class="arrow_text">/</span>&nbsp;</span><span class="arrow sep">&#x25BA;</span> <span tabindex="0">New account</span></li></ul></div>
                <div class="navbutton"> </div>
            </div>
            </div>
<!-- END OF HEADER -->

    <div id="page-content">
        <div id="region-main-box">
            <div id="region-post-box">

                <div id="region-main-wrap">
                    <div id="region-main">
                        <div class="region-content">
                                                        <div role="main"><span id="maincontent"></span>
<form autocomplete="off" action="http://elecslal.net/login/signup.php" method="post" accept-charset="utf-8" id="mform1" class="mform">
	<div style="display: none;"><input name="sesskey" type="hidden" value="iJhtJyp6Mi" />
<input name="_qf__login_signup_form" type="hidden" value="1" />
<input name="mform_isexpanded_id_createuserandpass" type="hidden" value="1" />
<input name="mform_isexpanded_id_supplyinfo" type="hidden" value="1" />
</div>

	<div class="collapsible-actions"><span class="collapseexpand">Expand all</span></div>

	<fieldset class="clearfix collapsible"  id="id_createuserandpass">
		<legend class="ftoggler">Choose your username and password</legend>
		<div class="fcontainer clearfix">
		
		<div id="fitem_id_username" class="fitem required fitem_ftext "><div class="fitemtitle"><label for="id_username">Username<img class="req" title="Required field" alt="Required field" src="http://elecslal.net/theme/image.php/standard/core/1393363531/req" /> </label></div><div class="felement ftext"><input maxlength="100" size="12" name="username" type="text" id="id_username" /></div></div>
		<div class="fitem femptylabel"><div class="fitemtitle"><div class="fstaticlabel"><label> </label></div></div><div class="felement fstatic">The password must have at least 8 characters, at least 1 digit(s), at least 1 lower case letter(s), at least 1 upper case letter(s), at least 1 non-alphanumeric character(s)</div></div>
		<div id="fitem_id_password" class="fitem required fitem_fpassword "><div class="fitemtitle"><label for="id_password">Password<img class="req" title="Required field" alt="Required field" src="http://elecslal.net/theme/image.php/standard/core/1393363531/req" /> </label></div><div class="felement fpassword"><input maxlength="32" size="12" autocomplete="off" name="password" type="password" id="id_password" /></div></div>
		</div></fieldset>
	<fieldset class="clearfix collapsible"  id="id_supplyinfo">
		<legend class="ftoggler">More details</legend>
		<div class="fcontainer clearfix">
		
		<div id="fitem_id_email" class="fitem required fitem_ftext "><div class="fitemtitle"><label for="id_email">Email address<img class="req" title="Required field" alt="Required field" src="http://elecslal.net/theme/image.php/standard/core/1393363531/req" /> </label></div><div class="felement ftext"><input maxlength="100" size="25" name="email" type="text" id="id_email" /></div></div>
		<div id="fitem_id_email2" class="fitem required fitem_ftext "><div class="fitemtitle"><label for="id_email2">Email (again)<img class="req" title="Required field" alt="Required field" src="http://elecslal.net/theme/image.php/standard/core/1393363531/req" /> </label></div><div class="felement ftext"><input maxlength="100" size="25" name="email2" type="text" id="id_email2" /></div></div>
		<div id="fitem_id_firstname" class="fitem required fitem_ftext "><div class="fitemtitle"><label for="id_firstname">First name<img class="req" title="Required field" alt="Required field" src="http://elecslal.net/theme/image.php/standard/core/1393363531/req" /> </label></div><div class="felement ftext"><input maxlength="100" size="30" name="firstname" type="text" id="id_firstname" /></div></div>
		<div id="fitem_id_lastname" class="fitem required fitem_ftext "><div class="fitemtitle"><label for="id_lastname">Surname<img class="req" title="Required field" alt="Required field" src="http://elecslal.net/theme/image.php/standard/core/1393363531/req" /> </label></div><div class="felement ftext"><input maxlength="100" size="30" name="lastname" type="text" id="id_lastname" /></div></div>
		<div id="fitem_id_city" class="fitem fitem_ftext "><div class="fitemtitle"><label for="id_city">City/town </label></div><div class="felement ftext"><input maxlength="120" size="20" name="city" type="text" id="id_city" /></div></div>
		<div id="fitem_id_country" class="fitem fitem_fselect "><div class="fitemtitle"><label for="id_country">Country </label></div><div class="felement fselect"><select name="country" id="id_country">
	<option value="" selected="selected">Select a country</option>
	<option value="AF">Afghanistan</option>
	<option value="AX">Åland Islands</option>
	<option value="AL">Albania</option>
	<option value="DZ">Algeria</option>
	<option value="AS">American Samoa</option>
	<option value="AD">Andorra</option>
	<option value="AO">Angola</option>
	<option value="AI">Anguilla</option>
	<option value="AQ">Antarctica</option>
	<option value="AG">Antigua And Barbuda</option>
	<option value="AR">Argentina</option>
	<option value="AM">Armenia</option>
	<option value="AW">Aruba</option>
	<option value="AU">Australia</option>
	<option value="AT">Austria</option>
	<option value="AZ">Azerbaijan</option>
	<option value="BS">Bahamas</option>
	<option value="BH">Bahrain</option>
	<option value="BD">Bangladesh</option>
	<option value="BB">Barbados</option>
	<option value="BY">Belarus</option>
	<option value="BE">Belgium</option>
	<option value="BZ">Belize</option>
	<option value="BJ">Benin</option>
	<option value="BM">Bermuda</option>
	<option value="BT">Bhutan</option>
	<option value="BO">Bolivia, Plurinational State Of</option>
	<option value="BQ">Bonaire, Sint Eustatius And Saba</option>
	<option value="BA">Bosnia And Herzegovina</option>
	<option value="BW">Botswana</option>
	<option value="BV">Bouvet Island</option>
	<option value="BR">Brazil</option>
	<option value="IO">British Indian Ocean Territory</option>
	<option value="BN">Brunei Darussalam</option>
	<option value="BG">Bulgaria</option>
	<option value="BF">Burkina Faso</option>
	<option value="BI">Burundi</option>
	<option value="KH">Cambodia</option>
	<option value="CM">Cameroon</option>
	<option value="CA">Canada</option>
	<option value="CV">Cape Verde</option>
	<option value="KY">Cayman Islands</option>
	<option value="CF">Central African Republic</option>
	<option value="TD">Chad</option>
	<option value="CL">Chile</option>
	<option value="CN">China</option>
	<option value="CX">Christmas Island</option>
	<option value="CC">Cocos (Keeling) Islands</option>
	<option value="CO">Colombia</option>
	<option value="KM">Comoros</option>
	<option value="CG">Congo</option>
	<option value="CD">Congo, The Democratic Republic Of The</option>
	<option value="CK">Cook Islands</option>
	<option value="CR">Costa Rica</option>
	<option value="CI">Côte D'Ivoire</option>
	<option value="HR">Croatia</option>
	<option value="CU">Cuba</option>
	<option value="CW">Curaçao</option>
	<option value="CY">Cyprus</option>
	<option value="CZ">Czech Republic</option>
	<option value="DK">Denmark</option>
	<option value="DJ">Djibouti</option>
	<option value="DM">Dominica</option>
	<option value="DO">Dominican Republic</option>
	<option value="EC">Ecuador</option>
	<option value="EG">Egypt</option>
	<option value="SV">El Salvador</option>
	<option value="GQ">Equatorial Guinea</option>
	<option value="ER">Eritrea</option>
	<option value="EE">Estonia</option>
	<option value="ET">Ethiopia</option>
	<option value="FK">Falkland Islands (Malvinas)</option>
	<option value="FO">Faroe Islands</option>
	<option value="FJ">Fiji</option>
	<option value="FI">Finland</option>
	<option value="FR">France</option>
	<option value="GF">French Guiana</option>
	<option value="PF">French Polynesia</option>
	<option value="TF">French Southern Territories</option>
	<option value="GA">Gabon</option>
	<option value="GM">Gambia</option>
	<option value="GE">Georgia</option>
	<option value="DE">Germany</option>
	<option value="GH">Ghana</option>
	<option value="GI">Gibraltar</option>
	<option value="GR">Greece</option>
	<option value="GL">Greenland</option>
	<option value="GD">Grenada</option>
	<option value="GP">Guadeloupe</option>
	<option value="GU">Guam</option>
	<option value="GT">Guatemala</option>
	<option value="GG">Guernsey</option>
	<option value="GN">Guinea</option>
	<option value="GW">Guinea-Bissau</option>
	<option value="GY">Guyana</option>
	<option value="HT">Haiti</option>
	<option value="HM">Heard Island And Mcdonald Islands</option>
	<option value="VA">Holy See (Vatican City State)</option>
	<option value="HN">Honduras</option>
	<option value="HK">Hong Kong</option>
	<option value="HU">Hungary</option>
	<option value="IS">Iceland</option>
	<option value="IN">India</option>
	<option value="ID">Indonesia</option>
	<option value="IR">Iran, Islamic Republic Of</option>
	<option value="IQ">Iraq</option>
	<option value="IE">Ireland</option>
	<option value="IM">Isle Of Man</option>
	<option value="IL">Israel</option>
	<option value="IT">Italy</option>
	<option value="JM">Jamaica</option>
	<option value="JP">Japan</option>
	<option value="JE">Jersey</option>
	<option value="JO">Jordan</option>
	<option value="KZ">Kazakhstan</option>
	<option value="KE">Kenya</option>
	<option value="KI">Kiribati</option>
	<option value="KP">Korea, Democratic People's Republic Of</option>
	<option value="KR">Korea, Republic Of</option>
	<option value="KW">Kuwait</option>
	<option value="KG">Kyrgyzstan</option>
	<option value="LA">Lao People's Democratic Republic</option>
	<option value="LV">Latvia</option>
	<option value="LB">Lebanon</option>
	<option value="LS">Lesotho</option>
	<option value="LR">Liberia</option>
	<option value="LY">Libya</option>
	<option value="LI">Liechtenstein</option>
	<option value="LT">Lithuania</option>
	<option value="LU">Luxembourg</option>
	<option value="MO">Macao</option>
	<option value="MK">Macedonia, The Former Yugoslav Republic Of</option>
	<option value="MG">Madagascar</option>
	<option value="MW">Malawi</option>
	<option value="MY">Malaysia</option>
	<option value="MV">Maldives</option>
	<option value="ML">Mali</option>
	<option value="MT">Malta</option>
	<option value="MH">Marshall Islands</option>
	<option value="MQ">Martinique</option>
	<option value="MR">Mauritania</option>
	<option value="MU">Mauritius</option>
	<option value="YT">Mayotte</option>
	<option value="MX">Mexico</option>
	<option value="FM">Micronesia, Federated States Of</option>
	<option value="MD">Moldova, Republic Of</option>
	<option value="MC">Monaco</option>
	<option value="MN">Mongolia</option>
	<option value="ME">Montenegro</option>
	<option value="MS">Montserrat</option>
	<option value="MA">Morocco</option>
	<option value="MZ">Mozambique</option>
	<option value="MM">Myanmar</option>
	<option value="NA">Namibia</option>
	<option value="NR">Nauru</option>
	<option value="NP">Nepal</option>
	<option value="NL">Netherlands</option>
	<option value="NC">New Caledonia</option>
	<option value="NZ">New Zealand</option>
	<option value="NI">Nicaragua</option>
	<option value="NE">Niger</option>
	<option value="NG">Nigeria</option>
	<option value="NU">Niue</option>
	<option value="NF">Norfolk Island</option>
	<option value="MP">Northern Mariana Islands</option>
	<option value="NO">Norway</option>
	<option value="OM">Oman</option>
	<option value="PK">Pakistan</option>
	<option value="PW">Palau</option>
	<option value="PS">Palestine, State Of</option>
	<option value="PA">Panama</option>
	<option value="PG">Papua New Guinea</option>
	<option value="PY">Paraguay</option>
	<option value="PE">Peru</option>
	<option value="PH">Philippines</option>
	<option value="PN">Pitcairn</option>
	<option value="PL">Poland</option>
	<option value="PT">Portugal</option>
	<option value="PR">Puerto Rico</option>
	<option value="QA">Qatar</option>
	<option value="RE">Réunion</option>
	<option value="RO">Romania</option>
	<option value="RU">Russian Federation</option>
	<option value="RW">Rwanda</option>
	<option value="BL">Saint Barthélemy</option>
	<option value="SH">Saint Helena, Ascension And Tristan Da Cunha</option>
	<option value="KN">Saint Kitts And Nevis</option>
	<option value="LC">Saint Lucia</option>
	<option value="MF">Saint Martin (French Part)</option>
	<option value="PM">Saint Pierre And Miquelon</option>
	<option value="VC">Saint Vincent And The Grenadines</option>
	<option value="WS">Samoa</option>
	<option value="SM">San Marino</option>
	<option value="ST">Sao Tome And Principe</option>
	<option value="SA">Saudi Arabia</option>
	<option value="SN">Senegal</option>
	<option value="RS">Serbia</option>
	<option value="SC">Seychelles</option>
	<option value="SL">Sierra Leone</option>
	<option value="SG">Singapore</option>
	<option value="SX">Sint Maarten (Dutch Part)</option>
	<option value="SK">Slovakia</option>
	<option value="SI">Slovenia</option>
	<option value="SB">Solomon Islands</option>
	<option value="SO">Somalia</option>
	<option value="ZA">South Africa</option>
	<option value="GS">South Georgia And The South Sandwich Islands</option>
	<option value="SS">South Sudan</option>
	<option value="ES">Spain</option>
	<option value="LK">Sri Lanka</option>
	<option value="SD">Sudan</option>
	<option value="SR">Suriname</option>
	<option value="SJ">Svalbard And Jan Mayen</option>
	<option value="SZ">Swaziland</option>
	<option value="SE">Sweden</option>
	<option value="CH">Switzerland</option>
	<option value="SY">Syrian Arab Republic</option>
	<option value="TW">Taiwan</option>
	<option value="TJ">Tajikistan</option>
	<option value="TZ">Tanzania, United Republic Of</option>
	<option value="TH">Thailand</option>
	<option value="TL">Timor-Leste</option>
	<option value="TG">Togo</option>
	<option value="TK">Tokelau</option>
	<option value="TO">Tonga</option>
	<option value="TT">Trinidad And Tobago</option>
	<option value="TN">Tunisia</option>
	<option value="TR">Turkey</option>
	<option value="TM">Turkmenistan</option>
	<option value="TC">Turks And Caicos Islands</option>
	<option value="TV">Tuvalu</option>
	<option value="UG">Uganda</option>
	<option value="UA">Ukraine</option>
	<option value="AE">United Arab Emirates</option>
	<option value="GB">United Kingdom</option>
	<option value="US">United States</option>
	<option value="UM">United States Minor Outlying Islands</option>
	<option value="UY">Uruguay</option>
	<option value="UZ">Uzbekistan</option>
	<option value="VU">Vanuatu</option>
	<option value="VE">Venezuela, Bolivarian Republic Of</option>
	<option value="VN">Viet Nam</option>
	<option value="VG">Virgin Islands, British</option>
	<option value="VI">Virgin Islands, U.S.</option>
	<option value="WF">Wallis And Futuna</option>
	<option value="EH">Western Sahara</option>
	<option value="YE">Yemen</option>
	<option value="ZM">Zambia</option>
	<option value="ZW">Zimbabwe</option>
</select></div></div>
		</div></fieldset>
	<fieldset class="hidden"><div>
		<div id="fgroup_id_buttonar" class="fitem fitem_actionbuttons fitem_fgroup"><div class="felement fgroup"><input name="submitbutton" value="Create my new account" type="submit" id="id_submitbutton" /> <input name="cancel" value="Cancel" type="submit" onclick="skipClientValidation = true; return true;" class=" btn-cancel" id="id_cancel" /></div></div>
		<div class="fdescription required">There are required fields in this form marked <img alt="Required field" src="http://elecslal.net/theme/image.php/standard/core/1393363531/req" />.</div>
		</div></fieldset>
</form></div>                                                    </div>
                    </div>
                </div>

                
                
            </div>
        </div>
    </div>

<!-- START OF FOOTER -->
            <div id="page-footer" class="clearfix">
        <p class="helplink"></p>
        <div class="logininfo">You are not logged in. (<a href="http://elecslal.net/login/index.php">Log in</a>)</div><div class="homelink"><a href="http://elecslal.net/">Home</a></div>    </div>
        <div class="clearfix"></div>
</div>
<script type="text/javascript">
//<![CDATA[
M.str = {"moodle":{"lastmodified":"Last modified","name":"Name","error":"Error","info":"Information","morehelp":"More help","loadinghelp":"Loading...","cancel":"Cancel","yes":"Yes","changesmadereallygoaway":"You have made changes. Are you sure you want to navigate away and lose your changes?","collapseall":"Collapse all","expandall":"Expand all"},"repository":{"type":"Type","size":"Size","invalidjson":"Invalid JSON string","nofilesattached":"No files attached","filepicker":"File picker","logout":"Logout","nofilesavailable":"No files available","norepositoriesavailable":"Sorry, none of your current repositories can return files in the required format.","fileexistsdialogheader":"File exists","fileexistsdialog_editor":"A file with that name has already been attached to the text you are editing.","fileexistsdialog_filemanager":"A file with that name has already been attached","renameto":"Rename to \"{$a}\"","referencesexist":"There are {$a} alias\/shortcut files that use this file as their source","select":"Select"},"block":{"addtodock":"Move this to the dock","undockitem":"Undock this item","dockblock":"Dock {$a} block","undockblock":"Undock {$a} block","undockall":"Undock all","hidedockpanel":"Hide the dock panel","hidepanel":"Hide panel"},"langconfig":{"thisdirectionvertical":"btt"},"admin":{"confirmation":"Confirmation"}};
//]]>
</script>
<script type="text/javascript">
//<![CDATA[
YUI().use('node', function(Y) {
M.util.load_flowplayer();
setTimeout("fix_column_widths()", 20);
M.yui.galleryversion="2010.04.08-12-35";Y.use("moodle-core-dock-loader",function() {M.core.dock.loader.initLoader();
});
M.util.help_popups.setup(Y);
M.yui.galleryversion="2010.04.08-12-35";Y.use("moodle-core-popuphelp",function() {M.core.init_popuphelp();
});
M.yui.galleryversion="2010.04.08-12-35";Y.use("moodle-core-formchangechecker",function() {M.core_formchangechecker.init({"formid":"mform1"});
});
M.yui.galleryversion="2010.04.08-12-35";Y.use("moodle-form-shortforms",function() {M.form.shortforms({"formid":"mform1"});
});
M.yui.galleryversion="2010.04.08-12-35";Y.use("moodle-form-passwordunmask",function() {M.form.passwordunmask({"formid":"id_password","checkboxlabel":"Unmask","checkboxname":"password"});
});
 M.util.js_pending('random5d923ff92d6e42'); Y.on('domready', function() { M.util.js_complete("init");  M.util.js_complete('random5d923ff92d6e42'); });

});
//]]>
</script>
</body>
</html>